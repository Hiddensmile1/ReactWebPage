import React from 'react'
import  "./style.css"

const Contact = () => {
  return (
    <div className='contactCon'>
      <form className='formCon'>
        <h1>Contact Us</h1>
         <div className='inputCon' >
          <label>First Name :</label>
          <input placeholder='First Name' />

         </div>
         <div className='inputCon' >
          <label>Last Name :</label>
          <input placeholder='Last Name' />

         </div>

         <div className='inputCon' >
          <label>Email :</label>
          <input placeholder='Email' />

         </div>

         <div className='inputCon' >
          <label>Message :</label>
          <textarea cols={54} rows={10} placeholder='Message' />

         </div>

         <button>Submit</button>
      </form>
    </div>
  )
}

export default Contact